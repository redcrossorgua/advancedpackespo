/***********************************************************************************
 * The contents of this file are subject to the Extension License Agreement
 * ("Agreement") which can be viewed at
 * https://www.espocrm.com/extension-license-agreement/.
 * By copying, installing downloading, or using this file, You have unconditionally
 * agreed to the terms and conditions of the Agreement, and You may not use this
 * file except in compliance with the Agreement. Under the terms of the Agreement,
 * You shall not license, sublicense, sell, resell, rent, lease, lend, distribute,
 * redistribute, market, publish, commercialize, or otherwise transfer rights or
 * usage to the software or any modified version or derivative work of the software
 * created by or for you.
 *
 * Copyright (C) 2015-2025 Letrium Ltd.
 *
 * License ID: b9e93c849e46ee6531f976f5d6bf5ecc
 ************************************************************************************/

define('advanced:views/bpmn-user-task/detail', ['views/detail'], function (Dep) {

    return Dep.extend({

        setup: function () {
            Dep.prototype.setup.call(this);

            if (!this.model.get('resolution')) {
                if (this.getAcl().checkModel(this.model, 'edit')) {
                    this.addMenuItem('buttons', {
                        label: 'Resolve',
                        action: 'showResolveModal',
                        acl: 'edit',
                    });

                    this.listenTo(this.model, 'sync', () => {
                        if (this.model.get('resolution')) {
                            this.removeMenuItem('showResolveModal');
                        }
                    });

                    this.listenTo(this.model, 'change:resolution', () => {
                        if (this.model.get('resolution')) {
                            this.disableMenuItem('showResolveModal');
                        } else {
                            this.enableMenuItem('showResolveModal');
                        }
                    });
                }
            }
        },

        actionShowResolveModal: function () {
            this.createView('modal', 'advanced:views/bpmn-user-task/modals/resolve', {
                model: this.model,
            }, view => {
                view.render();
            });
        },
    });
});
